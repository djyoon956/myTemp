package shoes.factory_03.shoes;

public class BrownShoes extends Shoes{


}
