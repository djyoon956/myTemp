package factory_03.shoes.france;

import factory_03.Shoes;

public class FRStyleBrownShoes extends Shoes {

	@Override
	public void prepare() {
		// TODO Auto-generated method stub

	}

	@Override
	public void packing() {
		// TODO Auto-generated method stub

	}

}
