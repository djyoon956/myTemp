package shoes.factory_03.shoes;

public class BlueShoes extends Shoes{
	
	public BlueShoes() {
		name="그냥 다정이를 위한 블루 슈즈><♥♥♥♥";
	}
	
}
