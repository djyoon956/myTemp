package pizza_01.pizza.chicago;

import pizza_01.pizza.Pizza;

public class ChicagoStyleClamPizza extends Pizza {

}
