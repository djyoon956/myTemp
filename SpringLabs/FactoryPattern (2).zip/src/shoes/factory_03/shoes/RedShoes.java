package shoes.factory_03.shoes;

public class RedShoes extends Shoes {



}
