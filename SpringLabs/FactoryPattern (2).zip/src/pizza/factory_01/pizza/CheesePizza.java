package pizza.factory_01.pizza;

public class CheesePizza extends Pizza {
	public CheesePizza() {

	}
}
