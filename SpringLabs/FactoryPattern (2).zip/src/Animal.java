
public abstract class Animal {
	public String name;

	public void move() {
		System.out.println("어슬렁 어슬렁");
	}

	abstract void howl();
}
