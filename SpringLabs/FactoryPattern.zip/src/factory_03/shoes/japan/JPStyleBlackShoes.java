package factory_03.shoes.japan;

import factory_03.Shoes;

public class JPStyleBlackShoes extends Shoes {

	public JPStyleBlackShoes() {
		name = "일본 스타일의 검은 구두";
		bottom = "검은색 고무 밑창";
		leather = "소가죽";
		hasPattern = false;
	}
}
