package pizza_01.pizza.chicago;

import pizza_01.pizza.Pizza;

public class ChicagoStyleVeggiePizza extends Pizza {

}
