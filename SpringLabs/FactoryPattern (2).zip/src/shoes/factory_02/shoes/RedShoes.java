package shoes.factory_02.shoes;

public class RedShoes extends Shoes {

	public RedShoes() {
		name = "빨간색 구두";
		bottom = "옅은 빨간색 플라스틱과 고무 혼용";
		leather = "양가죽";
	}
}
