package pizza.factory_01.pizza;

public class ClamPizza extends Pizza {

}
