package pizza_01.pizza.newyork;

import pizza_01.pizza.Pizza;

public class NYStyleClamPizza extends Pizza {

}
