package shoes.factory_03.shoes;

public class BlackShoes extends Shoes{

	public BlackShoes() {
		name="그냥 블랙 슈즈><";
	}

}
